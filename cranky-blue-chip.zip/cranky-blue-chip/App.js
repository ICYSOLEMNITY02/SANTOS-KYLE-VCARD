import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, Button, Linking, ScrollView, TouchableOpacity, TextInput } from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Card, Avatar } from 'react-native-paper';

const VCard = ({ owner }) => {
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [date, setDate] = useState(new Date());
  const [time, setTime] = useState(new Date());
  const [message, setMessage] = useState('');

  const handleAppointment = () => {
    alert(`Appointment requested for ${owner.name} on ${date.toDateString()} at ${time.toLocaleTimeString()}`);
  };

  const handleSendMessage = () => {
    Linking.openURL(`mailto:${owner.email}?subject=Contact&body=${message}`);
  };

  return (
    <Card style={styles.card}>
      <View style={styles.header}>
        <Avatar.Image size={100} source={{ uri: owner.avatar }} style={styles.avatar} />
        <View style={styles.headerText}>
          <Text style={styles.name}>{owner.name}</Text>
          <Text style={styles.jobTitle}>{owner.jobTitle}</Text>
          <Text style={styles.company}>{owner.company}</Text>
        </View>
      </View>
      <Card.Content style={styles.content}>
        <Text style={styles.about}>{owner.about}</Text>
        <Text style={styles.detail}><Text style={styles.boldText}>Groupchat:</Text> {owner.phoneNumber}</Text>
        <Text style={styles.detail}><Text style={styles.boldText}>Ride Sched:</Text> {owner.email}</Text>
        <Text style={styles.detail}><Text style={styles.boldText}>Other Admins:</Text> {owner.businessHours}</Text>
        <Text style={styles.detail}><Text style={styles.boldText}>Finished Route:</Text></Text>
        <View style={styles.services}>
          {owner.services.map((service, index) => (
            <Text key={index} style={styles.serviceItem}>• {service}</Text>
          ))}
        </View>
        
        <Text style={styles.detail}><Text style={styles.boldText}>Last Ride:</Text></Text>
         <Image size={80} source={require('./drt.jpg')} style={styles.logo} />
      </Card.Content>
      <View style={styles.qrCodeContainer}>
        <Image source={{ uri: owner.qrCode }} style={styles.qrCode} />
      </View>
      <Card.Content style={styles.appointment}>
        <Text style={styles.appointmentLabel}>Next Ride Schedule:</Text>
        <TouchableOpacity onPress={() => setShowDatePicker(true)} style={styles.datePicker}>
          <Text style={styles.datePickerText}>{date.toDateString()}</Text>
        </TouchableOpacity>
        {showDatePicker && (
          <DateTimePicker
            value={date}
            mode="date"
            display="default"
            onChange={(event, selectedDate) => {
              setShowDatePicker(false);
              setDate(selectedDate || date);
            }}
          />
        )}
        <Text style={styles.appointmentLabel}>RIDEOUT TIME:</Text>
        <TouchableOpacity onPress={() => setShowTimePicker(true)} style={styles.datePicker}>
          <Text style={styles.datePickerText}>{time.toLocaleTimeString()}</Text>
        </TouchableOpacity>
        {showTimePicker && (
          <DateTimePicker
            value={time}
            mode="time"
            display="default"
            onChange={(event, selectedTime) => {
              setShowTimePicker(false);
              setTime(selectedTime || time);
            }}
          />
        )}
        <Button title="Click to be apart of this ride" onPress={handleAppointment} color="#4FC3F7" />
      </Card.Content>
      <Card.Content style={styles.contact}>
        <TextInput
          style={styles.textInput}
          placeholder="Type your message"
          value={message}
          onChangeText={setMessage}
        />
        <Button title="Send Message" onPress={handleSendMessage} color="#4FC3F7" />
      </Card.Content>
      <View style={styles.socialMedia}>
        {owner.socialMedia.map((account, index) => (
          <TouchableOpacity key={index} onPress={() => Linking.openURL(account.url)} style={styles.socialMediaLink}>
            <Image source={{ uri: account.icon }} style={styles.socialMediaIcon} />
            <Text style={styles.socialMediaText}>{account.platform}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </Card>
  );
};

const sampleOwner = {
  name: 'Kyle Santos',
  jobTitle: 'ADMIN K',
  company: 'SNV',
  phoneNumber: 'SIKLISTA NG VALENZUELA',
  email: 'Week days',
  about: "Hello Everyone! My name is kyle, and I’m excited to be a part of this vibrant community of cyclists. Cycling has been a passion of mine for 2 years, and I find immense joy and freedom in every ride. Cycling, for me, is not just a sport but a way of life. It keeps me fit, clears my mind, and brings me closer to nature. I’m looking forward to riding together, sharing adventures, and making great memories.",
  businessHours: 'Admin adam and Admin raffy',

  
  services: ['Bulacan', 'Pampanga', 'Tarlac', 'Rizal', 'pasig', 'Tagaytay', 'Dampalit', 'Moa', 'Nueva Ecija',],
  products: 'https://www.facebook.com/messages/t/65366195697743961', 
  qrCode: 'https://scontent.xx.fbcdn.net/v/t1.15752-9/440844558_704450921713036_8620368254142803708_n.png?stp=dst-png_p206x206&_nc_cat=111&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeFJK2IYYyoHIL56EykB6xSwwuSz3lggSmzC5LPeWCBKbKoOTammJ9tRkT4upobzJxGXSG95CWd_AXErY5zoDaQH&_nc_ohc=9IFCVxK58sEQ7kNvgGPcHQR&_nc_oc=AdjQHdyN5k4JBsVGM4q0eAJC5mOab3cw3sZiABElRLT4HMjs3uPwNcIKbuemdXUObZAj74kcZjMKl07PDX74CoTc&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&oh=03_Q7cD1QGhQEd9BMAPUo4nyMXVwNo-x4jojQsFbg7af6r8zgnnaw&oe=666B04B7',
  avatar: 'https://scontent.fmnl3-2.fna.fbcdn.net/v/t39.30808-6/434299078_2207851416220989_3252858627507875568_n.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeGvZD6krEsUuhy0ZmA8Kr1CCGLbZLGy3ycIYttksbLfJ9WlbTdg_btL1XbhrKFYFtHCnUe7Fm598eStUrXf3-H6&_nc_ohc=4A6PADfcMEUQ7kNvgHUH6YB&_nc_ht=scontent.fmnl3-2.fna&oh=00_AYDutm0FSM8S-rWQQODpBvthqIHQEl2O-R2MwpUa329TCg&oe=664B708D',
  socialMedia: [
    { platform: 'Facebook', url: 'https://www.facebook.com/kccsnts', icon: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/f1a2b5a4e002935c0ac1e6dcf8d25270' },
    { platform: 'Messenger', url: 'https://m.me/j/Abad_rxWB9vyNHhU/', icon: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw8NDQ8QDQ4NEA8PEA8OEA4ODhANEA8NFhUWFhUVFRUYHiggGBolHRYVITUhJS8rLy4uFx8zODUsPSgtMCsBCgoKDg0OFxAQGislHyUrLSsrLS0tLSsuLS8rLSsrNS0tKy0rLS0tMjctLS0rLS0tKy0vLS8rListLS0rKy0tLf/AABEIAOEA4QMBEQACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAAAQIFBgcEA//EAEQQAAEDAgIGBQkFBgUFAAAAAAEAAgMEEQUxBhIhQVFhEyJxgZEHFCMyQlJyobFigrLB0TNjc5KiwhUkNENTdIPS4fH/xAAbAQEAAwEBAQEAAAAAAAAAAAAAAQIDBQQGB//EADoRAAIBAgQCCQMDAgQHAAAAAAABAgMRBBIhMQVRE0FhcYGRobHRMsHwFCLhM0IjUnLxFSQ0Q2KCkv/aAAwDAQACEQMRAD8A7igCAIAgCAIAgCApNK2Npc9zWtGbnENA7SULRhKTtFXZgq7TCkiuGF8zv3ber/MbA911VyR06PB8RPWSUV2/C+9jB1WnEzv2UUTBxeXSn8h9VRzZ0afA6S+uTfdp8mMn0krJM6h4HBgbHbvAuqOUuZ7YcNw0NoLxu/c8b8Qmd608zvilefqVR3N1h6UdoJeCPkZCcyT2klUaNMqWwa8jIkdhsq5SHFM+8dbK31ZpW/DI8fQqNV1mcqFN7xXkj2wY/Vs9WokPx2k/ECp6Sa6zzzwGHlvBeGnsZOm0xnb+0ZFIOV43eO0fJWWJmt0eOpwai/pbXr+eZmaPS6mfskD4jxcNdvi3b4haxxMHvoc+rwitH6bS9H6/Jm6eoZK3Wjex7eLHBw+S9Cknqjmzpzg7TTT7T6qSgQBAEAQBAEAQBAEAQBAEAQBAfCsq44GF8z2sYPacbbeA4nkhpTpTqyywV2afi2nBN20bLDLpZRt+6z9fBWyncw3BlvWfgvu/jzNUrK2Wd2tNI+Q7tY3A7BkO5RlO3SpU6StTSR8LquU1uTdRlJuLquUXJuquIJBVXEWLAqriRYkFVcSLFgVRxIsSCquJFiwKo4kWPtT1D43a0b3Md7zCWn5KqvF3RSdOM1aSuu02PDNL5GWbUt6RvvsAa8doyPyXohimtJHIxHCIS1pOz5Pb59zbKGviqG60Lw4bwNhaeYzC9kJxmrpnDrUKlGWWaselWMQgCAIAgCAIAgCAIAgCA1zSLSuKkvHFaWcbCL9SM/bI3/ZHyWkabep0sHw6db909I+r7vn3OfYhiEtS/XneXu3X2Bo4NGQC2ULH0lGlToxywVkea6ZTW5N1XKLi6jKTcm6hxJuLqriTcm6q4k3JuqOJNybqriTckFUcQWBVHEWLAqriRYsCqOJWxYFZuJFiwKo4kWPtTVD4nh8b3McMnNNj/wCxyVU3F3RnUpxqRyzV0blgmlLZbR1NmPyEg2Meefun5dmS9tLEp6S3Pn8ZwuVO86Wq5da+TZV6jjhAEAQBAEAQBAEAQGiaV6X3LoKN9hta+oac+IjP93hxXqpUOuR3MDw5K1Squ5fPx5mlXXoynbuLplFxdRlFxdRlJuTdRlFybquUm4uquJNybqriTcm6q4k3JuqOJa5N1RxJuWBVHEtckFZuILAqjiLFgVRxK2LAqjiRYsCs3EixcFZtFTY9HtI3QWinJdFk1+bo/wBW/T5LejXcf2y2OTjuGqredPSXLn/JvDHBwBaQQQCCDcEHIgroXufNtNOzJQgIAgCAIAgCA0HTXSjWLqWmd1Rds0jT6x3xtPDid+XG/uw+H/ul4Hb4fgrWq1F3L7/HmaTdezKdi4umUXJumUXF1GUXF1GUm5N1GUXJuq5Sbi6q4k3JuquJNybqjiWuTdUcSblrqjiWuSCqOJNyQVm4lrlgVm4lrlgVRxBYFZuJFiwKzaIsWBWbRWxcFZtEWNh0Zx407hFMfQuOwn/acd/w8fHitqFbI8r2OTxDAdMs8Pq9/wCf9jewbroHzJKAIAgCAIDVNOdIfNY+ghdaeUdZwO2KI7L/ABHaB3ngvZhMPneZ7L1OjgML0ks8tl6s5nddbKd64umUXF0yi4uoyi5N0yi4uoyk3Juq5Sbi6q4i5N1VxLXJuquJNybqjiTcsCqOJa5IKo4k3JBVHEtcsCs3EsmSCs3EsmWBWbiWTLArNxJLArNoWLArNorYuCs2iLFgVk0VsbjodjN7U0p2gehceA9j9PDcF6sPV/sfgcDiuCt/jQ8fn5NtXrOEEAQBAePF8QZSU8k0nqsF7ZFzsmtHMmwWlKm6k1FdZpSpupNRXWcYrqx9RK+WU3fI4ucd3IDkBYDkF9HCkoRUVsj6WEVCKjHZHwurZS1xdTlFxdMouLqMouTdRlJuLqMouTdRlJuLqriTcm6q4k3JuqOJNyQVVxJuWBVHEtckFZuJa5IKo4k3LArNxLJlgVm4lkyQVk4l0ywKzcSyZYFZOJa5YFZtAuCs2iLFgVk0VsfWOQtIc0kOaQ4EZhw2ghZtWKSimmnsdLwLEhV07X7NcdWQDc8Z9xz710KU88bnx+Mwzw9Vx6t13GRWh5AgCA5r5ScX6SdtKw9SGz5Lb5nDYO5p/qPBd3hmHtB1H17d357HX4fSyxc31+xpl11Mp0bi6ZSLi6nKLi6jKLi6ZRcm6jKTcXUZRcm6rlJuLqriTcm6q4k3JuquJNybqjiWuWBVHEm5IKzcS1ywKo4lkyQVm4lkywKycSyZYFZuJZMsCsnEumWBWTiWTJBWTiWTLgrNoksCsmiC4KyaKtGe0SxLoKkNcfRzWjdyf7B8dn3lajLLLvOZxPDdLRbW8dfn87Doa9x8oEB5sRrG00Esz/ViY55HGwyHM5LSlTdScYLrdi0IuclFdZw2ondK98khu+RznuPFzjc/VfZRpqKUVsj6FWikkfK6tlJuLqcpFxdMouLplFxdMouTdRlJuLqMpNybqriLi6q4k3JuquJNybqjiWuWBVHEm5IKo4lrkgrNxLJlgVm4lkywKzcSyZIKzcSyZYFZOJZMsCsnEumWBWTiWTLArJxLplgVlKJZMuCsmiSwKyaILgrJoqdSwKu85pY5D6xGq/427D9L969tOWaKZ8XjKHQ1pQ6uruZ71c8ppnlQr+jpI4Qds8lyOMcdnH+osXY4NRz1XP8Ayr1f8XPbgo3m5cvucwuvp8p07kXU5RcXU5SLi6ZRcXTKLi6jKLk3TKTcXVcpNybqHEm5N1RxJuLqriTcsCqOJNyQVRxLXJBVHElMsCs3EsmSCs3EsmWBWbiWTLArJxLplgVk4lky11k4l0zZsB0Rmqm9JK7oIztbrN1nvHENuLDmfDevLUqJaI5+J4nCi8sf3P0R5tIdH5KBzbuEkb7hsgGr1h7JG2x+u1UTUj0YLHRxKelmuoxAKq0e9MsCsZRLplwVk0SXBWTRDNx0Aq9s0JPCZo/pd/Yr0Xuj5/jdHSFTwfuvubkvQfPnKfKbV9JiAjB2QxMbbg913H5FngvrOC08uHzc37afJ08IrU782aiuuem4Qi4UEXJQXCC5CE5gpFwhNz6QxOke1kbS57yGta3aXOOwAKspRinKWiROZJXZ0zR7QGGJrX1vppTY9HciJh4bPXPbs5L5jF8XnNuNHRc+t/H5qc+rjJPSGi9TZRglGG6vmlLq+70EdvCy5n6qve+eV+9nm6Wpe+Z+ZgMd0Dpp2l1KBTy5gC5hceBb7Pa3wK92G4rVg7VP3L18/k9NLGzi7S1Xqc2xChlpZTFOxzHjccnD3mnIjmF9BTqQqxzwd0dSFSM1eLPOCjiaJlgVRxLJlgVk4lkyQVm4lkywKycS6Z9qeJ8j2sja573GzWtFyT2LGdkrslzUVdvQ6Jozoc2DVlqw2SXYWxetHGefvO+Q55rl1sRm0jscTF8RlP8AZT0XPrfwbcvKcs0TyiYm1zo6ZtiY3CWQ+67VIa3ts4nvC9FGGlzvcIoON6r69EaaCrSid1MsCsZIumWBWMkXTLgrJoGZ0UqeiroTfY8mM89YWHz1VWGkkc/iVPPhp9mvl/Fzpq9J8ccR0qn6XEat3797O5nUH4V9xgYZMNTXYn56/c6lLSEUYpeovcIRcIRmCC4QZgguEJuEJudD8mmA2BrZW7TdlOCMm5Ok79rRyvxXzvGcZ/2I/wDt9l9/LkeTE1f7F4nQF8+eMIAgPBjOEQV0XR1DNYZtcNj43cWu3H5Hfdb4fE1KEs0H8PvNKdWVN3icq0l0Ynw92s70kBNmztGwXyDx7J+R+Q+nwmNp4lWWkuXxzOvQxMaunXyMGCvU4npTLArNxLJlgVk4lkzJYJg09dJqQN2C2vI7YyMczx5DavLXqwpK8vIpVxEKSvLyOp6P6PQUDLRjWkcLPmcOs7kPdbyHfdcGviJVXrtyOHiMVOs9duRl1geYxukGKtoqZ8rrF3qxsPtynIdmZPIFaUqbnKx6MNQdaoorx7jkUszpHue9xc95LnOOZcdpK6LjZWR9ZBKKSWyAKxkjRMsCsZIumXBWMkXTLArGSLo+1NN0b2P9xzX/AMpB/JZNFakM8XHmmvM7BrjiPFeg+Bszgtc/Xnld70sjvFxK+/pLLCK7F7HQT0R8FcXJQi4QXCDMEGYILhCbmV0ZwZ1fVMiFxGOvK8ezEM7Hich233LyY3FLDUnPr2XeVnUyq52qGJsbWsYA1rGhrWjYGtAsAF8TKTk3J7s8Ddy6gBAEAQFZI2vaWvaHNcCHNcA4EHMEHMKU2ndEp21RzrSnQRzNaagBc3N1Nm5vExnePs58L7AvoMFxVStCvo+fz8+fM6NDGX/bU8/k0a9r32WuDfZYjO67LidFM2rRbQ+Ws1ZZ9aKnzBtaSUfZByb9o918xycbj4UbxjrL0Xf8Hlr4xU/2x1fsdPoqOKnjbHCxrGNya36nieZXz06kpyzSd2cic5TeaTuz7qhUEoDk2l2Oee1J1D6CK7IuDvef3/QDmuxQodHDXd7n0mCw/Q09d3v8GEBVpI96ZcFYyRdMsCsZIumXBWMkXTLArGSLplljJF0bj/jJ4/NRc4H6JHNTmv0c5NyEIuEIuEFwhFwguEJuSASbAEk7AALkngAouTc7HobgQoKUBwHTy2fMeDtzL8GjZ23O9fG8Rxf6irdfStF8+J5pyzMzy8BQIAgCAIAgCA8U2EUsknSSU1O6TYekdCxz7jLrEXW0cRVjHKptLld2LqrNKybt3ntWJQIAgNP8oWO9BD5tE70sw65GbIMj3u2jsDuS6GAw+eXSPZe50cBQzS6SWy9zm4K6skdxMsCsZIumXBWMkXTLArGSLplwVjJF0ywKwkjRMuCsZIumfbpHLOxFkYWpZqyPb7r3N8CQv0ODvFPsPiMx81ci4Qi4Qi4QXCC4Qm5unk4wHppfO5W+jhNogcnz+92N+p5LicYxmSHQx3e/d/Pt3lZS6jpq+YMwgCAXQBAEAQBAEAQBAeTFcQZSQSTSnqxtvbe52TWjmTYd61o0pVZqEesvTpupJRRxbEK59TNJNKbvkdrHgBuaOQFh3L6iFKNOChHZH0VOKhFRXUfEFUkjZMsCsZIumXBWMkXTLArGSLplwVhJF0y4Kxki6Za6wkjRGwf4SeCyOd+rRrOkEPR11U3hUTEfCXkj5EL7vCSzUKb/APFex8rcx63IuEIuEIuSgzBBmPZhGGvrKiOCLN52utcMYPWcewfkN6xxFeNCm6kur17Bc7ZQUbKaGOGIWZG0NaN/aeJOZPNfEVasqs3OW7B6FmASgNE0q06DNaGgIc/aHVOxzG8o9zjzy7d3ewPCHK06+3L55d2/cXjHmc8fM8ydIXvMt9bpS5xk1uOtndfRKMVHKlpy6vI1TN70W07tqw4gdmwNqbeAkH9w795XBx3CL3nQ/wDn4+PLkUlDrR0Jjg4AtIIIBBBuCDkQV88007MyJUAIAgCAIDlflBx7zmo83id6GncQSMpJ8iexu1vbrcl9NwzB9FT6SW8vRfzv5HXwdHJHM937Gqgr3yR7kywKxki6ZYFYyRdMuCsJIumXBWMkaJlgVhJF0y4Kxki6Z9GNLiGjNxDR2nYFhJF8yWrOweYM4LznxXTzOXeUOm6PEpDulZHKPDUPzYV9fwmpmwsVybX3+5g2a2ukVuEK3CC4Qi4QXOq6AYD5pT9NK2084BsRtjhza3kTme4bl8pxXGdNUyR+mPq+f2X8msTa1ySTzYhXRU0TpZ3tYxubjvPADMnkFpSozqyUIK7By7SnTCWuvHFrRU2Wrfryj7ZG77I777vqcDwyGHtKWsvRd3yRc1hdQsmFJdMIXTNg0Z0rmw8hpvLTk7YSdreJjO48sjyvdc7G8Op4lX2lz+fy/sHFSOqYTisNZEJKd4c3IjJzHe64bivla+HqUJ5ait9+4xaa3PasCAgCA1rTrH/MabVjdaonuyO2bG+1J3XsOZHArp8Lwf6ireX0x37ez86j0YalnlrsjkIX1skdhMuCsZIumWBWMkXTLgrCSLplgVjJF0y4KwkjRMuCsJIumXBWMkaIyejcHS11Mz96157Gdc/hXmqaJmOMqZMPN9lvPT7nXV5T440Pyp0V2U84HqudC7scNZv4XfzLv8Dq2lOn4+WhSZztfRGVyUK5ghGYILmx6CYKKyr1pADFT6sj2n23EnUaeVwSfhtvXN4pinQo2jvLRfdl6auzri+QPQYXSPSWDD2dc68xF2QNI1jzcfZbz8Lr24PA1MS9NI9b/NyspJHKcaxmeul1533tfUjGxkY4NH55lfWYbC08PHLBd762ZZrmPXoJTCF0whZMhC6YUmiZ68MxKaklEtO8seNh3te33XDeFjXoU60MlRXX5sW0e50/R7TSmq2hszmwT5Fj3WY88WOOzuO3tzXy+L4VVou8Fmj2b+K++xlKDRswN8lyyhhsc0opaJp15A+XdBGQ55PP3RzPzXtwvD62Ieisub2/nwNIUpT2OSY1iktbO6aYjWdsa0eqyMZNHLae8kr67DYeGHpqnD/d8zpU4qCsjwL0G6ZYFZyRdMsCsJI0TLgrCSLplwVjJF0ywKwkjRMuCsJIui4WEkaI2/yc0mvUSynKKPVHxvP6NPivHXdlY5fF6tqUYc37HQ15T54xmkmHed0U8I9ZzLs/it6zfmB4r04Ov0NeM+q+vc9GVkrqxxNfcHjuFBFwhGYIMxndEtIDh0znFhfFKA2RrbB2y5a5t94udnNeHH4P9VBJOzWxenUys2TGvKE0x6tDG8POcszWgM+Ftzc9uztXMw3BWpXrNW5Lr8fzwNZV1/aaDNK6R7nyOc57jdznEuc48SV9BGKilGKskY5iisSmELJkIXTCF0whdMhC6YUmiZCGiZIcQLAkNObQSAe5RZXuaJlQLKxomFBomENUwEZomWBWMkaIuFhJF0WCwkjRMuFhJF0XCwkjRFwsJIujqmhFB0FCwkWfMTM7sdbV/pDfErl15Xmz5viNbpK7tstPzxM+sjwBAcj07wnzWtc5otHUXmZwDifSN8TfscF9fwvE9NQSe8dH9vzsPFWWWXea6uiYXCEZghGYILhCcwQm4QsmQhdMKSyZCGiYQumENEyELphSapkIaJhDRMhDRMIapkKTVMsFSSNEWCwki6LhYSRoi4WEkXRYLCSNEZXR3DTWVUcVurfXkPCJvreOwdrgvHXnki2Z4mv0NJz6+rv/ADU7EBbYMhuXHPlSUAQGE0uwbz6kcxoHSs9JEcuuPZ7CLjwO5e7h+K/T1lJ7PR/nYZVoZ426zjpBBsQQRsIIsQeBC+yOW2QhGYIRcIMwQm4Qm4QumELJkIXTCkumQhomENEwhomQhomFJqmQhomENUyENUwhomEZqmWCxkjRFwsJIuiwWEkaIuCsJI0R1LQPBvNqbpZBaWos6xzZF7LeRN7ntA3Lh4urnnZbI4XEMR0k8q2XubOvIc8IAgCA5x5Q9H+jeauFvo5D6cD2JDsD+x2/n2r6ThGNzR6Gb1W3dy8PbuOdi6VnnW3WaSu2eC4QZggzBCbhCUyFJdMIXTCF0whdMhSaJkIaphDRMIaJkKTVMIapkIaJkIaphDVMhSaplgs5I0RcLCSNEWC88kaI2jQfAPPJ+klb/l4SC6+UkmYZ2ZE9w3rmY6v0ccq3Z5cZieihlju/T86jqq4RwQgCAIAgKTRNkY5j2hzHgtc1wuHNOwgq0ZOLUo7ohpNWZyPSzR12Hy9W7qeQnon52Oeo4+8PmO+312AxqxMNfqW6+6/NDiYmg6Mux7fBgl7zzXCDMQhNwhZMIWTCkumQhomENEyENEwpNEyENUwhqmQhomFJqmQhqmENUyENUENYgKGaouFhJGiMto7gslfOI49jRZ0slriNnHmTuG/uK8GKrxoQzPwXMpWrxpRzPwOxYfRR00LIoW6rGCwG88STvJO2/NfL1KkqknKW7OFUnKcnKW56FQoEAQBAEAQHwrqOOoidFMwPjeLOafkQdxGd9y0pVZ0pqcHZopOEZxcZLQ5LpPo5Jh8g2l8DyRHLv46r+DreOY3gfW4LHRxMeUluvuuz2OBicPKg+aezMIvcea4QsmELJkIXTCGiYUl0yENUwhomQhqmFJomQhqmENUQpNUENUQhrEhDVBDVBGbIy2j2BzYhLqRCzW26SVw6kbfzPBu/kNq8GMxUMPG8t+pc/wA5lataNJXfkdfwbCoqKERQNsBtc47XSP3ucd5/+L5KvXnWnnn/ALHHq1ZVJZpHuWJmEAQBAEAQBAEBgtN4Q/Dai49VrZByc1wP6+K9/DJOOKhbr0PJjop4ed+/yOQr68+auQpLJhC6YQumQhomENEwpNUyENUwhomQpNUyENUENokKTWIQ1RCGqIQ1QKGsTaNF9DJq3Vkm1oafPWItJKPsA5D7R7rrl43ilOheMNZei7/j2KVcTGGi1Z1LD6GKlibFAxrI25NHHeScyeZXytWtOrJzm7s5s5ubvI9KzKhAEAQBAEAQBAEBidLG3w6r/gvPgLr14B2xNPvR5cb/ANPU7mcaX2Z8pcIWTIQumFJqmENEyENUwhqmQpNUENUQpNUQhrEIaohDVBSbIhDVGSwfAKquP+XiJbkZX9SIfe39guV5sRjKOHX+JLXl1+XyWc4x3OiaPaDU9LaSe1RMNo1m2iYfss3nmeGyy+cxfF6ta8Yftj6vx+PUwniJS0WiNsXJMAgCAIAgCAIAgCAIAgMbpKL0FX/08x8GFenBv/mKf+pe558Z/Qqf6X7HF19qfGphC6ZCGiYaCSAASSbAAXJPADel7as1jyM7TaH4hKzWFOWjMCR7I3H7pNx32XhnxPDQds1+7X88D3wwdaSvl8zwVuB1cH7WmmaBm4ML2j7zbj5reni6FT6Zr29HqHRqR+qLMdcL0iLCGqCGqIQ2iFJrEqShqj20eE1NRboKeaQHJzY3an8x2fNY1MTSpfXJLx+25qjYcO8n1ZJYzuigbvBPTPH3W7P6lzq3GqEPoTl6L119DTNY23CtB6Kns57DUPG+azm35MHV8brkV+LYironlXZ87kOozZWtAAAAAGwAbAAuY3fcoSgCAIAgCAIAgCAIAgCAID41lOJopInerIx8bre64EH6q9ObhNTXU7+RSpBTg4vZq3mcWxTDpaSV0UzS1zTsPsvbuc07wV9rQrwrQU4PT2Piq1GdCbhNfyfKkpZJ36kMb5Hn2WNLiOZ4DmVedSFNZpuy7SaUJ1HaCu+w27CPJ/K+zqyQRN/44rPk73eqO665GI4zCOlJX7Xt5b+x2aHCZvWq7di389vc3XCsEpqMf5eFrTaxkPWkPa47e7JcSvi61d/vl4dXkdejh6dFfsXz5mRXmNwgPNVYfBN+2ghk/iRsf9QtIVqkPok13OxWUIy3RjptE8PfnSRD4NaP8JC9MeI4qO037+5ToKfI8ztB8OP+w4dk835uWq4tiv8AN6L4I6CHIDQfDv8Agcf+/N/5J/xbFf5vRfBboYcj7xaIYczKlYfjc+T8RKzlxLFS3m/ReyLKEUZClwqmh/ZU8EZ4siY0+IC888RVn9Um+9smx7FiSEAQBAEAQBAEAQBAEAQBAEAQBAEBrHlB/wBH3rqcJ/rHM4r/AEGT5P8A/RDt/JRxb+uW4X/QRsy5h0QgCAIAgCAIAgCAIAgCAIAgCAIAgCAIAgCAID//2Q==' },
    { platform: 'GitHub', url: '', icon: 'https://via.placeholder.com/24?text=GH' }
  ]
};

export default function App() {
  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollView}>
        <VCard owner={sampleOwner} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffd6d5',
    padding: 20,
  },
  scrollView: {
    flexGrow: 1,
    justifyContent: 'center',
  },
  card: {
    borderRadius: 15,
    borderColor: '#000000',
    backgroundColor: '#D3D3D3',
    elevation: 3,
    shadowOffset: {width: 1 , height: 1},
    shadowOpacity: 0.4,
    shadowRadius: 5,
    marginHorizontal: 4,
    marginVertical: 6,
    marginBottom: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    borderRadius: 15,
    backgroundColor: '#EF2B7C',
    borderColor: '#000',
    elevation: 3,
    shadowOffset: {width: 1 , height: 1},
    shadowOpacity: 0.4,
    shadowRadius: 5,
    marginHorizontal: 4,
    marginVertical: 6,
  },
  avatar: {
    marginRight: 15,
  },
  headerText: {
    flex: 1,
    
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  jobTitle: {
    fontSize: 16,
    color: '#777',
  },
  company: {
    fontSize: 16,
    color: '#777',
  },
  content: {
    paddingVertical: 20,
    paddingHorizontal: 20,
  },
  about: {
    fontSize: 16,
    width: 260,
    marginBottom: 40,
    
  },
  logo: {
    width: 100,
    height: 100,
  },
  detail: {
    fontSize: 16,
    marginBottom: 5,
    color: '#555',
  },
  boldText: {
    fontWeight: 'bold',
  },
  services: {
    marginTop: 10,
  },
  serviceItem: {
    fontSize: 16,
    color: '#555',
  },
  qrCodeContainer: {
    alignItems: 'center',
    padding: 20,
    
  },
  qrCode: {
    width: 100,
    height: 100,
  },
  appointment: {
    padding: 20,
  },
  appointmentLabel: {
    fontSize: 16,
    marginBottom: 10,
    color: '#555',
  },
  datePicker: {
    backgroundColor: '#FFE0B2',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
    alignItems: 'center',
  },
  datePickerText: {
    fontSize: 16,
  },
  contact: {
    padding: 20,
  },
  textInput: {
    borderColor: '#ccc',
    backgroundColor: '#FFE0B2',
    borderWidth: 1,
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
    fontSize: 16,
  },
  socialMedia: {
    flexDirection: 'row',
    justifyContent: 'center',
    padding: 10,
  },
  socialMediaLink: {
    marginHorizontal: 10,
    alignItems: 'center',
  },
  socialMediaIcon: {
    width: 24,
    height: 24,
  },
  socialMediaText: {
    marginTop: 5,
    fontSize: 12,
    color: '#555',
  },
});